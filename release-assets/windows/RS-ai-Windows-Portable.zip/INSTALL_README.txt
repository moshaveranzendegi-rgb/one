﻿RS ai portable build
- Start with RUN_RS-ai_Portable.bat or RS-ai.exe.
- FFmpeg is required and is not bundled.
- OmniAvatar models are not bundled; use tools\setup_avatar_wsl.bat in the source package.
- Keep the whole dist\RS-ai folder together; do not move RS-ai.exe alone.
